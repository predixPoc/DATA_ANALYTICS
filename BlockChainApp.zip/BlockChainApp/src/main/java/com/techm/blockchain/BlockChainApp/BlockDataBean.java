package com.techm.blockchain.BlockChainApp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "blockchain")
public class BlockDataBean {
@Id	
@GeneratedValue(strategy = GenerationType.AUTO)
private Long id;
private String chaincode;
private int previousHash;
private int currentHash;
private String tx_val;
private String tx_date;
private String status;

public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getChaincode() {
	return chaincode;
}
public void setChaincode(String chaincode) {
	this.chaincode = chaincode;
}
public int getPreviousHash() {
	return previousHash;
}
public void setPreviousHash(int previousHash) {
	this.previousHash = previousHash;
}
public int getCurrentHash() {
	return currentHash;
}
public void setCurrentHash(int currentHash) {
	this.currentHash = currentHash;
}
public String getTx_val() {
	return tx_val;
}
public void setTx_val(String tx_val) {
	this.tx_val = tx_val;
}
public String getTx_date() {
	return tx_date;
}
public void setTx_date(String tx_date) {
	this.tx_date = tx_date;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
