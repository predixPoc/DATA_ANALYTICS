package com.techm.blockchain.BlockChainApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockChainAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockChainAppApplication.class, args);
	}
}
