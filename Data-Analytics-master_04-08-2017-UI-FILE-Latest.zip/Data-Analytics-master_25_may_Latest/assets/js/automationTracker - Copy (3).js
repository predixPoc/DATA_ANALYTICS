 var summaryArray=[];
 var automationIdArray=[];
 var encryptedUserName="";
// var dounloadCount=0;
 var downloadCount=0;
 var userType;
 var serialNo=0;
 var userId;
  var dtTable;
   
 var projectNamevar,contributorNamevar,slnovar,automationNameVar;
 $(document).ready(function () {

  //  $(window).on('load', function(){
	    var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
		 if(userType == "Admin"){
		
                                  $("#automation").show();
                                }else{
									
                                  $("#automation").hide();
                                }
        var decryptedUserName=atob(encryptedUserName);
		
		getUserIdFromName(decryptedUserName)
		
        var validuserNameList="techm,testuser";
		
		
		
		
		
        //if(validuserNameList.includes(decryptedUserName)){
        if(queryParam.includes("userName")){
			
			
			showAutomationTableData();
			
			
			
			
			
               
        }else{
           //alert("Restrict");
           window.location="index.html";
        }
			
   // }); // End of onload function

	 $("#automationId").click(function(){
        window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
				
		 
	 });
	 
	 $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	  $("#demographicsId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });

		 
	 $("#fileId").click(function(){
		$("#trackerDetailsDiv").hide();
		$("#fileUploadDiv").show();
 
	 });
	 $("#trackerDetailsId").click(function(){
	    $("#fileUploadDiv").hide();
        $("#trackerDetailsDiv").show();
        window.location.reload();		
	   
	 });
	 
	 $("#fileSubmitBtnId").click(function(){
	      var form = $('#fileUploadform')[0];
          var formData = new FormData($("#fileUploadform")[0]);
          var filename = $("#uploadfile").val();
          var lastIndex = filename.lastIndexOf(".");
          var ext = filename.substring(lastIndex+1);
  
          var requestURL="";
          if(ext == "xlsx"){
             requestURL = "https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/uploadExcelFileForReuse";
          }else if(ext == "pptx" || ext =="pps"){
             requestURL="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/uploadFile";
          }
          $.ajax({
              type: "POST",
              enctype: 'multipart/form-data',
			  //contentType: "multipart/form-data",
              url: requestURL,
              data: formData,
              processData: false, 
			  contentType: false,
              cache: false,
              success: function (data) {
              //   $("#result").text(data);
                 console.log("SUCCESS : "+ data.status + data.message);
				 if(data.status==200 && data.message=="Success"){
				       $("#fileUploadMsgDiv").show();
                       $("#fileUploadMsgDiv").css("background-color", "rgba(8, 97, 43, 0.45)");
                       $("#fileUploadMsgDiv").html("File uploaded successfully.");
				 }
             },
             error: function (e) {
               //  $("#result").text(e.responseText);
                 console.log("ERROR : ", e);
             }
          });
	    
	 });
	 
		var ratingStarVal;
	 	 $("#contributorFeedBackId").click(function(){
			var projectNameText= $("#projectName").text();
			var automationNameText=$("#automationName").text();
			var automationId = automationIdArray[serialNo];
			var starRateval=$(".caption").find("span").text();
			var buttonval=$("#contributorFeedBackId").val();
			alert(buttonval);

			
				 var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/saveRewardDetails";
				$.ajax({
						url:predixurl,
                         type: "POST", //send it through post method
						contentType: "application/json",
							data :JSON.stringify({
						  automationName :$("#automationName").text(),
						  projectName : $("#projectName").text(),
						  comment:$("#commentId").val(),
						  starRating:$(".caption").find("span").text(),	
						  userId:userId,
						  contributorName:$("#contributorId").text(),
						  buttonval:$("#contributorFeedBackId").val(),
					     }),
                         success: function(responseData) {
							console.log(responseData.status);
                	         if((responseData.status == 200)&&(responseData.message == "Success")){
                	 	      console.log("Success");
                                  
                	         }else{
                	 	     
                	         }
				
     			},
                 error: function ( xhr, status, error) {
				 console.log("Error while Login");
				 
		        }
		});
		 });
	 
	 
	 

	 var dataset=[
    [
      "1",
      "GE Power",
      "IGEE",
      "CS ICAM DWH 2012",
      "ICAM NextGen Reporting Extracts Failure Reporting",
      "",
	  "Tableau",
	  "Talend 6.1, Tableau 10.1.4",
	  "2000",
	  "32000",
	  "All Tableu Support projects",
	  "Tableau extract level counts for each of the report would be compared with the DB level row counts for each of the constituent tables and the result along with refresh information for all the reports would be showcased in a single dashboard."

    ],
    [
      "2",
      "GE Power",
      "IGEE",
      "CS ICAM DWH 2012",
      "ICAM NextGen Replication Efficiency Automated Evaluation",
      "",
	  "Tableau",
	  "Talend 6.1, Tableau 10.1.4",
	  "100",
	  "3000",
	  "All Tableu Support projects",
	  "An automated solution was conceptualized which would pull table wise counts from OLTP and Replica All the disparities are reported through Tableau report to necessary stakeholders."
    ],
    [
      "3",
      "GE Power",
      "IGEE",
      "PS Backlog Job & Pacing Reports",
      "Integrate data from 10 different sources and tableau reports for pacing",
      "",
	  "Tableau",
	  "Talend 6.1, Tableau 10.1.4",
	  "6000",
	  "100000",
	  "Any business with Finance planning & reporting",
	  "End to End Financial Baklog report with 360 degree view."
    ],
    [
      "4",
      "GE Energy",
      "IGEE",
      "Industrial BI Development",
      "Automation of Qlik View Dashboard Refresh.",
      "",
	  "Informatica",
	  "Informatica 9.x",
	  "2400",
	  "40000",
	  "Any Support proejct, where report refresh is part of the acitivity",
	  "Step 1 : A status table in Database with columns Load_end_date and Flag was created Step 2: ETL design was changed ,upon the completion of ETL load one row will be inserted to the status table with sysdate and ‘Y’Step 3: ETL Status Check qvw script is created that looks for (sysdate,’Y’) in the status table in a Loop. So when there is no latest values in status table the task will keep on running and once it reads the latest values from the table it gets succeeded Step 4: Loading of data from DB to qvd starts after successful completion of ETL status check qvw script."
    ],
    [
      "5",
      "GE Energy",
      "IGEI",
      "EM Support",
      "Upload of Daily Financial Extract Files to Support central.",
      "",
	  "Informatica",
	  "",
	  "400",
	  "10000",
	  "All support proejcts",
	  "Step-1: Informatica generates 4 extracts (Orders, Sales, Backlogs and Converted Orders) in text format every day and keep the files in server Step 2: The script which is developed runs every 30 minutes and if any extract file is generated, it takes the file, converts to Excel format and uploads to the Support central library with proper naming Step 3: Users can directly download the files and validate."
    ],
    [
      "6",
      "IGEI",
      "EM Support",
      "Upload of Daily Financial Extract Files to Support central.",
      "ICAM NextGen Replication Efficiency Automated Evaluation",
      "",
	  "Informatica",
	  "Inforamtica 9.x",
	  "400",
	  "10000",
	  "All support proejcts",
	  "Step-1: Informatica generates 4 extracts (Orders, Sales, Backlogs and Converted Orders) in text format every day and keep the files in server Step 2: The script which is developed runs every 30 minutes and if any extract file is generated, it takes the file, converts to Excel format and uploads to the Support central library with proper naming Step 3: Users can directly download the files and validate."
    ],
    [
      "7",
      "GE Energy",
      "IGEI",
      "Industrial BI Development",
      "Update or Delete Record Directly from Qlikview",
      "",
	  "Qlickview",
	  "Qlickview",
	  "600",
	  "11000",
	  "All Qlickview reports",
	  "This implementation is great way to interact between OLTP and OLAP . Checks before implementing this :Qlikview Scripts are ran using Microsoft COM Automation. it will run on client-side and works fine if IE Plugin in Web are used,It’s one-way communication so, We are not able to trace status, Is it created in the folder path When we want to update more than one record then we need to use Dynamic Update in Qlikview.once published in server the user must have Qlikview administrator permission.."
    ],
    [
      "8",
      "GE Aviation",
      "MyEngine",
      "SPARK Streaming API Call & Handle Data",
      "ICAM NextGen Replication Efficiency Automated Evaluation.",
      "",
	  "SPARK, Python, Talend",
	  "",
	  "360",
	  "21600",
	  "Informatica job server",
	  "Informatica Proactive Monitoring tool – This automation sends email alerts when the server/services are down and the cache reaches 80% and reduces manual intervention."
    ],
    [
      "9",
      "GE Aviation",
      "IGET",
      "MyEngine",
      "SPARK Streaming API Call & Handle Data",
      "",
	  "SPARK, Python, Talend",
	  "",
	  "2400",
	  "48000",
	  "Processing large files in HDFS",
	  "Create a Spark API to take the data from real time sources and then load into the GP database. This requires installation of Spark in the server."
    ],
    [
      "10",
      "GE Aviation",
      "IGET",
      "GEA Enabling Tools",
      "Automate Informatica Object Migration",
      "",
	  "Informatica, UNIX",
	  "",
	  "720",
	  "43200",
	  "Informatica Object Migration",
	  "Integration between ServiceNow tool with Informatica migration server where objects are migrated based on the description in text file submitted by users."
    ]
    
  ]
  



  
  
	 
 }); // End of document.ready()
 myArrayNew = [
                    { "sTitle": "S.No", "mData": "serialNum" },
                    { "sTitle": "Business Name", "mData": "businessName" },
                //  { "sTitle": "IBU Name", "mData": "ibuName" },
                    { "sTitle": "Project Name", "mData": "projectName" },
                    { "sTitle": "Automation Name", "mData": "automationName" },
				    { "sTitle": "Summary", "mData": "summary" },
                    { "sTitle": "Technology", "mData": "technology" },
                    { "sTitle": "Version", "mData": "version" },
                    { "sTitle": "Effort Saving", "mData": "effortSaving" },
                    { "sTitle": "Saving To GE ($)", "mData": "savingToGE" },
                    { "sTitle": "Where can be Reused", "mData": "reused" },
				    { "sTitle": "Contact Person", "mData": "contactPerson" },
                    { "sTitle": "Artefacts", "mData": "uploadedFileName" },
					{ "sTitle": "Contributor Name", "mData": "contributorName" }
					//{ "sTitle": "ID", "mData": "automationId" }
				
              ]


function showAutomationTable(jsonData){
    dtTable=$('#example').addClass( 'nowrap' ).dataTable({
        "rowCallback": function( row, data, index ) {
           if(index%2 == 0){
              $(row).removeClass('myodd myeven');
              $(row).addClass('myodd');
           }else{
              $(row).removeClass('myodd myeven');
              $(row).addClass('myeven');
           }
        },
        "aaData": jsonData,
        dom: 'lBfrtip',
        "bFilter" : true, 
	    "bPaginate": true,
	    "lengthMenu": [5,10,15,20,25],
        buttons: ['excel' , 'print','copyHtml5'],
        "language": {
		   "emptyTable": "No data available in table"
	    },
        "scrollX": true,
        "aoColumns":myArrayNew,
		columnDefs: [
			   { targets: 9, render: $.fn.dataTable.render.ellipsis( 15 ) },
			   { targets: 4, render: $.fn.dataTable.render.ellipsis( 60 ) },
			   {
             
                  "render": function ( data, type, row ) {
                 	 if(data == '' || data == null){
					    
					    return data;
					 }else{
					    return data = '<a href="assets/ppt/'+data+'.pptx" onclick="updateDownloadCount();"><img src="assets/img/file-icon.jpg"/>&nbsp;' + data + '</a>';
					 }
                  },
                  "targets": 11
                },
			   {
                  "render": function ( data, type, row ) {
                 	  if(data == '' || data == null){
					    return data;
					  }else{
						return data = '<a  data-toggle="modal" href="#" data-target="#automationModal">' + data + '</a>';
					  }
                   },
                   "targets": 3
                },
				/*{
                   "targets": [ 13 ],
                   "visible": false
                },*/
		        ]
    }) // Data Table
	/*.yadcf([
	    {
            column_number: 1,
            filter_type: "auto_complete"
        },
        {
            column_number: 2,
            filter_type: "auto_complete"
        },
        {
            column_number: 3,
            filter_type: "auto_complete"
        },		
                                                         
    ]); */

    $('#example_length').find('label').css({"margin-left": "0px"});
    $('#example_length').find('label').css({"color": "black"});
    $('#example_filter').addClass("pull-right");
    $('#example_filter').find('label').css({"color": "black"});

 

 var table = $('#example').DataTable();
 var data1;
	$('#example tbody').on( 'click', 'tr', function () {
    projectNamevar = table.row($(this)).data().projectName;
	contributorNamevar=table.row($(this)).data().contributorName;
	slnovar=table.row($(this)).data().serialNum;
	automationNameVar=table.row($(this)).data().automationName;
	businessNamevar=table.row($(this)).data().businessName;
	contactPersonNamevar=table.row($(this)).data().contactPerson;
		showRowData();
	} );
 

} // End of showAutomationTable()





function showRowData() {
	
	//$('#example tr').each(function() {
		//alert("it is calling second");
       //  $(this).click(function() {
			// alert("it is calling third");
		  var contributorName = contributorNamevar;//alert($(rows[2]).find("td:eq(13)").html());
		  var projectName =projectNamevar;
          var automationName = automationNameVar;
	
		   //serialNo=;
		  // var automationId = automationIdArray[serialNo];
		 
		   		 var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/rewardAlreadyExist";
				$.ajax({
						url:predixurl,
                         type: "POST", //send it through post method
						contentType: "application/json",
						data :JSON.stringify({
						  automationName :automationNameVar,
						  projectName : projectNamevar,
						  contributorName:contributorNamevar,
						  userId:userId,
					     }),
						
                         success: function(responseData) {
						
						alert(responseData.message);
                	         if((responseData.status == 201)&&(responseData.message == "Exists")){
                	 	     
                                  $("#contributorFeedBackId").prop('value', 'update');
                	         }else{
								 $("#contributorFeedBackId").prop('value', 'save');
                	         }
				
     			},
                 error: function ( xhr, status, error) {
				 console.log("Error while Login");
				 
		        }
		});
		 if(automationId!=''){
			   totalCount(automationId);
		   }
		  
           var businessName = $(this).children('td').eq(1).text();
		  
		   var summary = summaryArray[slnovar];
		   var fileName=$(this).children('td').eq(11).text();
		   var contactPersonMail=$(this).children('td').eq(10).text();
		   var contributorName=$(this).children('td').eq(12).text();
		   
		   $('#projectName').html(projectNamevar);
		   $('#automationName').html(automationNameVar);
		   $('#summaryId').html(summary);
		   $('#contributorId').html(contributorNamevar);
		   if(fileName != '' ){
		   }else{
		      $('#pptFileId').html('');
		   }
		   $('#contactPersonID').html(contactPersonNamevar);
                        
        //});
    //});
	
} // End of showRowData()


function totalCount(automationId){
				var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getDownloadCount/"+automationId;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
                        console.log(responseData.status);
                        if(responseData.status == 200){
							if(null!=responseData.object[0].totalDownloadCount)
						      downloadCount = responseData.object[0].totalDownloadCount;
						    $('#pptFileId').html(downloadCount);
						 
                        }
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while fetching download count for PPT file.");
	                }
		        });
	
	
}
function updateDownloadCount(){
	
    $('#example tr').each(function() {
         $(this).click(function() {
		     var projectName = $(this).children('td').eq(2).text();
             var automationName = $(this).children('td').eq(3).text();
			 var serialNo=$(this).children('td').eq(0).text();
		     var automationId = automationIdArray[serialNo];
			 if(automationId!=''){
		        var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/updateDownloadCounter/"+automationId;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
                        console.log(responseData.status);
                        if(responseData.status == 200 && responseData.message=="Success"){
						    totalCount(automationId);
                        }
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while updating download count in Automation_Tracker table.");
	                }
		       });
		     }
			 
         });
    });
} // End of updateDownloadCount()


function getUserIdFromName(decryptedUserName1){
	
var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getUserIdFromUserName/"+decryptedUserName1;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
						
                        console.log(responseData.status);
                        if(responseData.status == 200 && responseData.message=="Success"){
						  userId=responseData.object.userId;
						
                        }else{
							
							
						}
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while updating download count in Automation_Tracker table.");
	                }
		       });
}

function showAutomationTableData(){
	 $("#loadingDiv").show();
             //alert('Hello'+ queryParam);
             var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getAllTrackerData";
		     $.ajax({
		          url:predixurl,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
                    console.log(responseData.status);
                    if(responseData.object.length > 0){
				        for (i = 0; i < responseData.object.length; i++) { 
                           //summaryArray[i] = responseData.object[i].summary;
						   summaryArray[responseData.object[i].serialNum] = responseData.object[i].summary;
						   automationIdArray[responseData.object[i].serialNum] = responseData.object[i].automationId;
                        }
						$("#loadingDiv").hide();
                        showAutomationTable(responseData.object);
                    }
				
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });
	
	
}

	
	
	
