var selected = [];
//var mfgDatatable;
var myJsonString;
var jsonObj;
var arr = new Array();      
var data;
        //var selected = [];
var table;
var dtTable;
var myArrayNew;
var sliderMinval=0;
var sliderMaxval=1000;
$(document).ready(function() {
$('.SlectBox3').SumoSelect();

	$(".signImage").click(function () {

    $signImage = $(this);
    $content1 = $signImage.next();
    $content1.slideToggle(500, function () {
        $signImage.text(function () {
            return $content1.is(":visible") ? "- Filter Parameters" : "+ Filter Parameters";
        });
    });

});

	
	
	$( "#slider-range" ).slider({
			range: true,
			min: sliderMinval,
			max: sliderMaxval,
			values: [ sliderMinval, sliderMaxval ],
			slide: function( event, ui ) {
				$( "#elapseTime111" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			}
		});
		$( "#elapseTime111" ).val( $( "#slider-range" ).slider( "values", 0 ) +
			" - " + $( "#slider-range" ).slider( "values", 1 ) );
	
	clearFlightFileds();
	$("#srcflighttableID").show();
	$("#srcflightFiltertableID").hide();
	$("#loading").hide();
     myArrayNew = [
                { "sTitle": "Flight Id", "mData": "flightId" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				{ "sTitle": "Record Type", "mData": "recordType" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				 { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
				 { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				 { "sTitle": "Strain Gauge 4", "mData": "strainGauge4" },
				  { "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
				  { "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
				   { "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				   { "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
				     { "sTitle": "Strain Gauge 9", "mData": "strainGauge9" },				
                { "sTitle": "Elevator Position", "mData": "elevatorPosition" },
                { "sTitle": "Peak Valley Indicator ", "mData": "peakValleyIndicator" },
				 { "sTitle": "Flap Position", "mData": "flapPosition" },
                { "sTitle": "Fleet Id", "mData": "fleetId" },               
				 { "sTitle": "Left Aileron Position", "mData": "leftAileronPosition" },
                { "sTitle": "Start Time", "mData": "startTime" },
                { "sTitle": "Retardant Door Open", "mData": "retardantDoorOpen" },
                { "sTitle": "Timestamp", "mData": "timestamp" },
                { "sTitle": "Retardant Tank Float", "mData": "retardantTankFloat" },
                { "sTitle": "Trigger Channel", "mData": "triggerChannel" },                
                { "sTitle": "Gear Up And Locked ", "mData": "gearUpAndLocked" },
				 { "sTitle": "Arm Retardant Tank Door", "mData": "armRetardantTankDoor" },                
                { "sTitle": "Beacon Start Stop Recording", "mData": "beaconStartStopRecording" },
                { "sTitle": "Start Date", "mData": "startDate" }               
            ];  	
function refreshMFGTable(jsonData){
     $('#invoicedataTable').dataTable({
     "aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":myArrayNew,
			   
			   "initComplete": function(settings){
					$('#invoicedataTable thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#invoicedataTable thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);

$('#invoicedataTable_filter').addClass("pull-right");
$('#invoicedataTable_paginate').css({"font-size":"12px"});
$('#invoicedataTable_info').css({"font-size":"12px","font-weight": "bold"});
$('#invoicedataTable_length').find('label').css({"margin-left": "900px"})

}
$("#flightClearBtnID").click(function (event) {
clearFlightFileds();
 });
function clearFlightFileds(){
	
	$("#datepicker").val('');
	jQuery("#errorVaildDate").text('');
	$('#FlighttimeID').empty();
	$("#datetimepicker1").val('');
	$("#datepickerToDate").val('');
	$("#datetimepicker2").val('');
	$("#EndMinute").val('');
	$("#EndSecond").val('');
	$("#EndMS").val('');
	

}

	refreshMFGTable(data);
		//loadInvoiceDataTable(data,myArrayNew);
	function refreshGridInvoiceDataTable(responseData) {
		
	$('#invoicedataTable').dataTable().fnDestroy();
		   
		   refreshMFGTable(responseData);
		   
    }


	
	
	
	 $( function() {
   $( "#datepicker" ).datepicker();
	var searcheDateID = $("#datepicker").val();
	});

  $('#datepicker').datepicker({
   changeMonth: true,
   changeYear: true,
   dateFormat: 'yy-mm-dd',
   yearRange: "2004:2017",
   onSelect: function(dateText,inst) {	
	var searcheDateID = $("#datepicker").val();
   searcheDateID = dateFormatt(searcheDateID);
	if($("#datepicker").val()!="" && $("#datepickerToDate").val()!="" && $("#datetimepicker1").val()!="" && $("#datetimepicker2").val()!=""){
		var fromDate= $("#datepicker").val();
		
		var toDate= $("#datepickerToDate").val();
		
		var fromTime=$("#datetimepicker1").val();
		
		var toTime=$("#datetimepicker2").val();
		
		getFlightIdFromDb(fromDate,fromTime,toDate,toTime);
		$("#loading").show();
		//$('select.SlectBox3')[0].sumo.unSelectAll();
	}
	
	}

	});
	
	
	$('#datepickerToDate').datepicker({
			changeMonth: true,
			changeYear: true,
			 dateFormat: 'yy-mm-dd',
			onSelect: function(dateText,inst) {	
		var searcheToDateID = $("#datepickerToDate").val();
	  searcheToDateID = dateFormatt(searcheToDateID);
	 if($("#datepicker").val()!="" && $("#datepickerToDate").val()!="" && $("#datetimepicker1").val()!="" && $("#datetimepicker2").val()!=""){
		
		var fromDate= $("#datepicker").val();
		
		var toDate= $("#datepickerToDate").val();
		
		var fromTime=$("#datetimepicker1").val();
		
		var toTime=$("#datetimepicker2").val();
		
		getFlightIdFromDb(fromDate,fromTime,toDate,toTime);
		$("#loading").show();
		//$('select.SlectBox3')[0].sumo.unSelectAll();
	}

	}

	});
	
	
	
	$("#datetimepicker2").blur(function(){
			
		if($("#datepicker").val()!="" && $("#datepickerToDate").val()!="" && $("#datetimepicker1").val()!="" && $("#datetimepicker2").val()!=""){
		
		var fromDate= $("#datepicker").val();
		
		var toDate= $("#datepickerToDate").val();
		
		var fromTime=$("#datetimepicker1").val();
		
		var toTime=$("#datetimepicker2").val();
		
		getFlightIdFromDb(fromDate,fromTime,toDate,toTime);
		$("#loading").show();
		//$('select.SlectBox3')[0].sumo.unSelectAll();
	}	
			
});
	
	$("#datetimepicker1").blur(function(){
			
		if($("#datepicker").val()!="" && $("#datepickerToDate").val()!="" && $("#datetimepicker1").val()!="" && $("#datetimepicker2").val()!=""){
		
		var fromDate= $("#datepicker").val();
		
		var toDate= $("#datepickerToDate").val();
		
		var fromTime=$("#datetimepicker1").val();
		
		var toTime=$("#datetimepicker2").val();
		
		getFlightIdFromDb(fromDate,fromTime,toDate,toTime);
		$("#loading").show();
		
		
	}	
			
});
	
	
	
	
	
	

	$("#recordTypeID").change(function () {
        var recordTypeValue = $("#recordTypeID").val();
       // alert(recordTypeValue);
		$('#chanelTypeID').empty();
		if (recordTypeValue == 'PE'){
			$('#chanelTypeID').empty();			
		}
		if (recordTypeValue == 'TR'){
			$('#chanelTypeID').empty();
			$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "10",
			text : "10"
		}));
		$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "11",
			text : "11"
		}));
		$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "18",
			text : "18"
		}));
$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "20",
			text : "20"
		}));
		
		}
    });
	
	$("#submitSrcFltID").click(function (event) {
		var searchstartTime='';
		var searchendTime='';
		var splitelapseTime;
		var elapseTimeLegend=$("#elapseTime111").val();
		splitelapseTime=elapseTimeLegend.split("-");
		searchstartTime=splitelapseTime[0].trim();
		searchendTime=splitelapseTime[1].trim();
		
	var searchDate = $("#datepicker").val();
	if(searchDate == ''){
	jQuery("#errorVaildDate").text('Please enter Date.');
	return;
	}else{
	searchDate = dateFormatt(searchDate);
	var searchTime = $("#FlighttimeID option:selected").text();
	var srchRecordTypeID = $("#recordTypeID").val();
    var srcchanelType = $("#chanelTypeID").val();	
	if(srchRecordTypeID =="PE"){
		srcchanelType ="''";
	}
	if(srchRecordTypeID =="0"){
		srcchanelType ="''";
	}
	
	var flighidList=$("#flightIDForFlightData").val();
	
	//searchGridData(searchDate,searchTime,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime);
	
	searchGridData(flighidList,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime);
	$("#loading").show();
	}
	

   });
   
    
   
   
  		//function searchGridData(searchDate,searchTime,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime){
			function searchGridData(flighidList,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime){
			var serviceURL = "https://aircraft-service4.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter2/"+flighidList+"/"+srchRecordTypeID+"/"+srcchanelType+"/"+searchstartTime+"/"+searchendTime;
			
			//alert(serviceURL);
			console.log("serviceURL"+serviceURL);
			
		$.ajax({
 
	url: serviceURL,
	
                type: "get", //send it through post method
			

				headers : {

			   'Content-Type' : 'application/json'
				},
                success: function(responseData) {
 
				//console.log('responseData'+JSON.stringify(responseData));
				data=responseData;
				  $("#loading").hide();
				var checked;
				var i = 0;
                $('input[type=checkbox]').each(function () {
                   if (this.checked) {
					   i=i+1;
					   
                   }
				  
               });
			    if(i >0){
					  // alert('cheked');
					   checkBoxfilter();
					    $("#srcflighttableID").hide();
				        $("#srcflightFiltertableID").show();
				   }
				   else{
					  // alert('unchekced');
				  refreshGridInvoiceDataTable(responseData)
				  $("#srcflighttableID").show();
				   $("#srcflightFiltertableID").hide();
				  
				   }
				//refreshMFGTable(responseData);
				
 
},
                error: function ( xhr, status, error) {
   
      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
	 $("#loading").hide();
    }
 
  });
 
  }

   function checkBoxfilter(){
	
			if (dtTable != null){
				dtTable.fnDestroy();
			}
			  
                $('input[type=checkbox]').each(function () {
					$("#elapsedTime").prop('checked', true);
                   if (this.checked) {
					   $("#invoicedataTable1").find('thead tr').append("<th>" +"Elapsed Time"+ "</th>");
                       $("#invoicedataTable1").find('thead tr').append("<th>" + $(this).attr("ColumnName") + "</th>");
                   }
               });
              var i = 0;
              $("#invoicedataTable1").empty();
                var myArray = [];
                $('input[type=checkbox]').each(function () {
					$("#elapsedTime").prop('checked', true);
					
                    if (this.checked) {
                        i = i + 1;
						for(j=0;j< myArrayNew.length;j++){
							//alert(myArrayNew[j].mData)
							if($(this).attr("ColumnValueName") == myArrayNew[j].mData){
								myArray.push(myArrayNew[j]
                         );
                    }
						}
					}
                });
               
                dtTable=$('#invoicedataTable1').dataTable({
                    "aaData": data,
                    "aoColumns": myArray,
                    dom: 'lBfrtip',
					"bFilter" : false, 
					"bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
                  buttons: ['excel' , 'print','copyHtml5'],
				     "initComplete": function(settings){
					$('#invoicedataTable1 thead th').each(function () {
					   var $td = $(this);
					   $('#invoicedataTable1 thead').css('background-color','rgb(70,130,180);');
					   $('#invoicedataTable1 thead').css('color','white');
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#invoicedataTable1 thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
												
				} 
                });
				$('#invoicedataTable1_length').find('label').css({"margin-left": "900px"})
				}



 
function getFlightDataTime(date){
	
 //console.log("response data with filter"+date);
 //06-27-2004",
 $('#FlighttimeID').empty();
$('#FlighttimeID').find('option:not(:first)').remove();
$('#FlighttimeID').append($("<option></option>").attr("value",0).text('-Select-')); 
       $.ajax({

   	url: "https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/getFlightTimeStampDetails/"+date,
	
	

   	type: "GET", //send it through post methodOfPayment

   //	data : postData,

   	headers : {

   'Content-Type' : 'application/json'
    },
   success: function(responseData) {
       //  alert("search data available "+ JSON.stringify(responseData).length);
  // console.log("response data with filter"+JSON.stringify(responseData));   
	
if(responseData.length){
//var items = JSON.(responseData));   



   $.each(responseData, function (i, item) {
	 //  alert(item.startTime);
    $('#FlighttimeID').append($('<option>', { 
	//alert(responseData.startTime
	
        value: item.startTime,
       text : item.startTime
    }));
	 $('#loaderID').hide();
	  jQuery("#errorVaildDate").text('');
});
}
else{
	 $('#loaderID').hide();
	 jQuery("#errorVaildDate").text('Please enter valid Date.');
	//alert('Enter valid Date')
}
  // refreshInvoiceDataTable(responseData);
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
 
   
    }

     function dateFormatt(searcheDateID) {
		//alert(searcheDateID);
   
				//var s = '2016-04-30';
			var fields = searcheDateID.split("/");
			var datenew = fields[0];			
			var mon = fields[1];
			var yr = fields[2];
			var newDate=datenew+'-'+mon+'-'+yr;
			newDate = newDate.replace(/\b0(?=\d)/g, '')
			//console.log('newDate'+newDate)
			return newDate;
}
 jQuery('[data-toggle="invNmberTooltip"]').tooltip(); 

      
		$("#myTab a").click(function(e){
    	e.preventDefault();
    	$(this).tab('show');
    });
	
	$("#FlighttimeID").change(function() {
	$("#loading").show();
		var date=dateFormatt($("#datepicker").val());
		var flightTime=$(this).val();
		//alert(date);
		//alert(flightTime);
		      $.ajax({
			url: "https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightMinMaxElapsedTimeForStartTime/"+date+"/"+flightTime,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			$("#loading").hide();
			//console.log("response data with filter"+JSON.stringify(responseData));   
			var obj = jQuery.parseJSON(JSON.stringify(responseData));
			//sliderMinval=obj.minElapsedTime;
			sliderMaxval=obj.maxElapsedTime;
			$( "#slider-range" ).slider({
			range: true,
			min: 0,
			max: obj.maxElapsedTime,
			values: [ sliderMinval, sliderMaxval ],
			slide: function( event, ui ) {
				$( "#elapseTime111" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			}
		});
		$( "#elapseTime111" ).val( $( "#slider-range" ).slider( "values", 0 ) +
			" - " + $( "#slider-range" ).slider( "values", 1 ) );
			
	
  // refreshInvoiceDataTable(responseData);
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
	});
	
	
	
	$("#flightIDForFlightData").change(function() {
		
		var flightIdval=$(this).val();
		scaleElapseTime($(this).val());
		
		$("#loading").show();
		
	});
	
	
	
	
	
	
	
	
 }); 

function getFlightIdFromDb(fromDate,fromTime,todate,toTime){

$('.SlectBox3').html('');
$('.SlectBox3')[0].sumo.reload();

	var flightIdUrl="https://aircraft-service4.run.aws-usw02-pr.ice.predix.io/view/getFlightsInDateRange2";
	$.ajax({
			url:flightIdUrl+"/"+fromDate+"/"+fromTime+"/"+todate+"/"+toTime,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			$("#loading").hide();
			$('.SlectBox3').SumoSelect();
			
			for (var i = 0; i < responseData.length; i++) {
					
				
				 $('select.SlectBox3')[0].sumo.add(JSON.stringify(responseData[i].flightId));
				
				
           }
			
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
	

}
	
	
	
	function scaleElapseTime(data){
	
	var flightIdUrl="https://aircraft-service4.run.aws-usw02-pr.ice.predix.io/view/getFlightsMaxElapsedTime";

	$.ajax({
			url:flightIdUrl+"/"+data,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			$("#loading").hide();
		   //alert(JSON.stringify(responseData))
		   
		   var obj = jQuery.parseJSON(JSON.stringify(responseData));
			//sliderMinval=obj.minElapsedTime;{"minElapsedTime":14,"maxElapsedTime":3810}
			sliderMaxval=obj.maxElapsedTime;
		   
		 	$( "#slider-range" ).slider({
			range: true,
			min: 0,
			max: obj.maxElapsedTime,
			values: [ sliderMinval, sliderMaxval ],
			slide: function( event, ui ) {
				$( "#elapseTime111" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			}
		});
		$( "#elapseTime111" ).val( $( "#slider-range" ).slider( "values", 0 ) +
			" - " + $( "#slider-range" ).slider( "values", 1 ) );
			
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
	
	}
	