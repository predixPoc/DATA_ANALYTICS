package com.ge.data.analytic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.data.analytic.entity.TeamInfo;

/**
 * TEAM tab : Team information details : Repository
 * 
 * @author predix -
 */
@Repository
public interface TeamInfoRepository extends JpaRepository<TeamInfo, Long>{
	
	
	String GET_TEAM_MEMBER_DETAILS_BY_EMPID = "from TeamInfo t where t.empId =?1";
	
	@Query(GET_TEAM_MEMBER_DETAILS_BY_EMPID)
	TeamInfo getTeamMemberDetails(long teamMemberId);
}
