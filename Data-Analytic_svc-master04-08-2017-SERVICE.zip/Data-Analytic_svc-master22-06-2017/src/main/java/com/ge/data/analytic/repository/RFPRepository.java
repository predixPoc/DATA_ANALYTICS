package com.ge.data.analytic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ge.data.analytic.entity.RFPDetails;

/**
 * RFP Collaterals tab : RFP information details : Repository
 * 
 * @author predix -
 */
@Repository
public interface RFPRepository extends JpaRepository<RFPDetails, Long>{
	
	
}
