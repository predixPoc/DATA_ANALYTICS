package com.ge.data.analytic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


/**
 * The persistent class for the REWARD database table.
 * 
 */

@Entity
@Table(name="REWARD")
@NamedQuery(name="Reward.findAll", query="SELECT r FROM Reward r")
public class Reward {
	@Id
	@SequenceGenerator(name="REWARD_REWARDID_GENERATOR", sequenceName="REWARD_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REWARD_REWARDID_GENERATOR")
	@Column(name="REWARD_ID")
	private long rewardId;
	
	@Column(name="USER_ID")
	private long userId;
	
	@Column(name="REWARD_NAME")
	private String rewardName;
	
	@Column(name="CONTRIBUTOR_NAME")
	private String contributorName;
	
	@Column(name="STAR_RATING")
	private String starRating;
	
	@Column(name="COMMENT")
	private String comment;
	
	@Column(name="projectName")
	private String projectName;
	
	@Column(name="automationName")
	private String automationName;
	
	@Transient
	private String buttonval;
	

	
	
	
	
	
	public String getButtonval() {
		return buttonval;
	}

	public void setButtonval(String buttonval) {
		this.buttonval = buttonval;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getAutomationName() {
		return automationName;
	}

	public void setAutomationName(String automationName) {
		this.automationName = automationName;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getStarRating() {
		return starRating;
	}

	public void setStarRating(String starRating) {
		this.starRating = starRating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public long getRewardId() {
		return rewardId;
	}

	public void setRewardId(long rewardId) {
		this.rewardId = rewardId;
	}

	public String getRewardName() {
		return rewardName;
	}

	public void setRewardName(String rewardName) {
		this.rewardName = rewardName;
	}

	public String getContributorName() {
		return contributorName;
	}

	public void setContributorName(String contributorName) {
		this.contributorName = contributorName;
	}

	
    

}


