package com.ge.data.analytic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the REWARD database table.
 * 
 */

@Entity
@Table(name="DOWNLOAD_COUNTER")
@NamedQuery(name="DownloadCounter.findAll", query="SELECT d FROM DownloadCounter d")
public class DownloadCounter {
	@Id
	@SequenceGenerator(name="DOWNLOAD_COUNTER_ID_GENERATOR", sequenceName="DOWNLOAD_COUNTER_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DOWNLOAD_COUNTER_ID_GENERATOR")
	@Column(name="DOWNLOAD_ID")
	private long downloadId;
	
	@Column(name="TOTAL_DOWNLOAD")
	private int totalNoOfDownload;

	public long getDownloadId() {
		return downloadId;
	}

	public void setDownloadId(long downloadId) {
		this.downloadId = downloadId;
	}

	public int getTotalNoOfDownload() {
		return totalNoOfDownload;
	}

	public void setTotalNoOfDownload(int totalNoOfDownload) {
		this.totalNoOfDownload = totalNoOfDownload;
	}
	
	
}



