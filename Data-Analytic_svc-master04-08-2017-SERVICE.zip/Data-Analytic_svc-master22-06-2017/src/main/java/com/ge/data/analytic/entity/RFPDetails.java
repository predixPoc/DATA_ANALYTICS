package com.ge.data.analytic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the RFP_DETAILS database table.
 * 
 */

@Entity
@Table(name="RFP_DETAILS")
@NamedQuery(name="RFPDetails.findAll", query="SELECT a FROM RFPDetails a")
public class RFPDetails {
	@Id
	@SequenceGenerator(name="RFP_DETAILS_SERIAL_NO_GENERATOR", sequenceName="RFP_DETAILS_SERIAL_NO_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="RFP_DETAILS_SERIAL_NO_GENERATOR")
	@Column(name="SERIAL_NO")
	private long serialNum;
	
	@Column(name="OPPORTUNITY_NAME")
	private String opportunityName;
	
	@Column(name="CRM_ID")
	private String crmId;
	
	@Column(name="HIGH_LEVEL_SUMMARY")
	private String highLevelSummary;
	
	@Column(name="OPPORTUNITY_CATEGORY")
	private String opportunityCategory;
	
	@Column(name="RECEIVED_DATE")
	private String receivedDate;
	
	@Column(name="SUBMITTED_DATE")
	private String submittedDate;
	
	@Column(name="PROGRAM_MANAGER_NAME")
	private String programManagerName;
	
	@Column(name="BRM_NAME")
	private String brmName;
	
	@Column(name="RFP_DOC")
	private String rfpDoc;
	
	@Column(name="PROPOSAL_DOC")
	private String proposalDoc;

	public long getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(long serialNum) {
		this.serialNum = serialNum;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getCrmId() {
		return crmId;
	}

	public void setCrmId(String crmId) {
		this.crmId = crmId;
	}

	public String getHighLevelSummary() {
		return highLevelSummary;
	}

	public void setHighLevelSummary(String highLevelSummary) {
		this.highLevelSummary = highLevelSummary;
	}

	public String getOpportunityCategory() {
		return opportunityCategory;
	}

	public void setOpportunityCategory(String opportunityCategory) {
		this.opportunityCategory = opportunityCategory;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(String submittedDate) {
		this.submittedDate = submittedDate;
	}

	public String getProgramManagerName() {
		return programManagerName;
	}

	public void setProgramManagerName(String programManagerName) {
		this.programManagerName = programManagerName;
	}

	public String getBrmName() {
		return brmName;
	}

	public void setBrmName(String brmName) {
		this.brmName = brmName;
	}

	public String getRfpDoc() {
		return rfpDoc;
	}

	public void setRfpDoc(String rfpDoc) {
		this.rfpDoc = rfpDoc;
	}

	public String getProposalDoc() {
		return proposalDoc;
	}

	public void setProposalDoc(String proposalDoc) {
		this.proposalDoc = proposalDoc;
	}
	

}
