package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;

import com.ge.data.analytic.entity.Reward;

@Repository
public interface RewardRepo extends JpaRepository<Reward, Long>{
	String GET_ALL_REWARD_NAME = "from Reward r where r.contributorName=?1";
	
	String GET_ALL_REWARD_EXIST = "from Reward r where r.automationName=?1 and r.projectName=?2 and r.contributorName=?3 and r.userId=?4";
	
	
	
	@Query(GET_ALL_REWARD_NAME)
	List<Reward> findRewardName(String contributorName);
    
	@Query(GET_ALL_REWARD_EXIST)
	Reward findExistingReward(String automationName, String projectName, String contributorName, long userId);

	//findByRewardId 

}

