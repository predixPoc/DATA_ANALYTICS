package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ge.data.analytic.entity.DownloadCounter;

public interface DownloadRepository extends JpaRepository<DownloadCounter, Long>{
	
	@Override
	List<DownloadCounter> findAll();

}
