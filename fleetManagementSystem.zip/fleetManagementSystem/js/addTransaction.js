var array;
	var chaincode;
	var previousHash=0;
	var currentHash;
	var tx_val;
	var tx_date;
	var status;
	var id;

   $(document).ready(function () {
	
    array=new Array();
	$('#submitId').click(function() {

	//$("#blockChainviewId").show();
	//$("#blockChainaddId").hide();
	
	var requestor=$("#requestor").val();
	var transaction=$("#transactionType").val();
	var reciever=$("#reciever").val();
	
	previousHash=currentHash;
	var bindingData=requestor+""+transaction+""+reciever;
	var validation=true;
	if(array.length>0){
	for(var a in array){
	if(array[a]==bindingData) {
		validation=false;
	}
	}
	}else{
	array.push(bindingData);
	}
	if(validation){
			
		 var requestURL="http://localhost:8080/test"
		$.ajax({
              type: "GET",
			  headers : {
			'Content-Type' : 'application/json'
			},
           
              url: requestURL+"/"+requestor+"/"+transaction+"/"+reciever,
              success: function (data) {
			  
				//var origibalJson=JSON.stringify(data);
				var jsondata=JSON.stringify(data)
				var data1 = jQuery.parseJSON(jsondata);
			$.each(data1, function(key, item) 
				{
				chaincode=item.chaincode;
				//previousHash=item.previousHash;
				currentHash=item.currentHash;
				tx_val=item.tx_val;
				tx_date=item.tx_date;
				status=item.status;
				id=item.id;
			});
				/*var markup = "<tr><td style='font-size: 15px;font-family:bold'>ChainCode: "+chaincode+"</td></tr><tr ><td style='font-size: 15px;font-family:bold'>PreviousHash: "+previousHash+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>CurrentHash: "+currentHash+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Transaction Value: "+tx_val+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Transaction Date: "+tx_date+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Status: "+status+"</td></tr>";*/
				
		var markup="<tr><td>"+id+"</td><td>"+requestor+"</td><td>"+tx_val+"</td><td>"+reciever+"</td><td>"+tx_date+"</td><td><input type='button' value='Details' onclick=showTransaction('"+chaincode+"','"+requestor+"','"+transaction+"','"+reciever+"','"+currentHash+"','"+status+"') /></td></tr>";
				
				
				
				
				 $("#dataTable1").append(markup);
				 $('#transactionModal').modal('toggle');
             },
             error: function (e) {
              
                 console.log("ERROR : ", e);
             }
          });
	}

      
    });
	
	
	
	
	
   });
   
   function showTransaction(id,requestor,transactionVal,reciever,currentHash,status){
	   $('#detailsTransactionModal').modal('show'); 
		$("#ChainCode").html(id);
		$("#requestorDet").html(requestor);
		$("#transaction").html(requestor+" "+transactionVal+" "+reciever);
		$("#recieverDet").html(reciever);
		$("#hashcode").html(currentHash);
		$("#transactionDate").html(tx_date);
	}