 var encryptedUserName="";
 var userType;
 var reuseprojectName;
 var reuseSummary;
 var reuseContactPersonName;
 var reuseAutomationName;
 var reuseExcelDownloadId;
 var reusedownloadCount;
 var reusedownloadCountval;
 var reuseContributorName;
  var userId;
 $(document).ready(function () {
	 $('#yearId').html(new Date().getFullYear());
		$("#loadingDiv").show();
	$(window).on('load', function(){
	        var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
            if(queryParam.includes("userName")){
				showReuseTableData();
            }else{
               window.location="index.html";
            }
			
     var decryptedUserName=atob(encryptedUserName);
		
		getUserIdFromName(decryptedUserName)
					
			
			
	});//End of onload()
	
	reuseArrayHeader = [
                { "sTitle": "S.No", "mData": "serialNum" },
                { "sTitle": "Business Name", "mData": "businessName" },
                { "sTitle": "Project Name", "mData": "projectName" },
				{ "sTitle": "Reusable Component Name", "mData": "reuseComponentName" },
				{ "sTitle": "Summary", "mData": "summary" },
				{ "sTitle": "Technology", "mData": "technology" },
				{ "sTitle": "Saving To GE ($)", "mData": "savingToGE" },
                { "sTitle": "Can be Reused", "mData": "reused" },
				{ "sTitle": "Contact Person", "mData": "contactPerson" },
				{ "sTitle": "Artefacts", "mData": "uploadedFileName" },
				{ "sTitle": "Total Download", "mData": "downloadCounter"},
				{ "sTitle": "Contributor Name", "mData": "contributorName" },
				{ "sTitle": "ReuseUseId", "mData": "reuseId" ,"visible": false}
              ]

	 $("#automationId").click(function(){
         window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 $("#workId").click(function(){
		window.location="poc.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	   $("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;		 
	 });
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  })
	 
	
	
	 
	 
  $("#ratingId").rating();
   $("#ratingId").rating("update", 0);	 
	 
	 
	 
 });


function showReuseTableData(){

var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getReuseData";
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
                       
						$("#loadingDiv").hide();
                        if(responseData.object.length > 0){
                           showReuseTable(responseData.object);
                        }
     		         },
                     error: function ( xhr, status, error) {
				       console.log("Error while fetching Automation tracker data.");
	                 }
		        });

}

  
function showReuseTable(jsonData){
    $('#reuseTable').addClass( 'nowrap' ).dataTable({
         "rowCallback": function( row, data, index ) {
            if(index%2 == 0){
                $(row).removeClass('myodd myeven');
                $(row).addClass('myodd');
            }else{
                $(row).removeClass('myodd myeven');
                 $(row).addClass('myeven');
            }
         },
         "aaData": jsonData,
         dom: 'lBfrtip',
         "bFilter" : true, 
	     "bPaginate": true,
	     "lengthMenu": [5,10,15,20,25],
         buttons: ['excel' , 'print','copyHtml5'],
         "language": {
		   "emptyTable": "No data available in table"
	     },
         // "scrollY": 200,
		 fixedHeader: true,
		
         "scrollX": true,
         "aoColumns":reuseArrayHeader,
		 columnDefs: [
			   { targets: 4, render: $.fn.dataTable.render.ellipsis( 60, true ) },
			   { targets: 7, render: $.fn.dataTable.render.ellipsis( 30 ) },
			   {
                 "render": function ( data, type, row ) {
                 	 if(data == ''){
					 
					    return data;
					 }else{
					    if(data=='Reuse Case studies'){
					    return data = '<a href="assets/ppt/'+data+'.pps"><img src="assets/img/file-icon.jpg"/>&nbsp;' + data + '</a>';
						}else{
							 return data = '<a href="assets/ppt/'+data+'.pptx"><img src="assets/img/file-icon.jpg"/>&nbsp;' + data + '</a>';
						}
					 }
                 },
                 "targets": 9
                },
				
				 {
                  "render": function ( data, type, row ) {
                 	  if(data == '' || data == null){
					    return data;
					  }else{
						return data = '<a  data-toggle="modal" href="#" data-target="#reUseModal">' + data + '</a>';
					  }
                   },
                   "targets": 3
                },
				
				
				
		    ]
    }); 
    $('#reuseTable_length').find('label').css({"margin-left": "0px"});
    $('#reuseTable_length').find('label').css({"color": "black"});
    $('#reuseTable_filter').addClass("pull-right");
    $('#reuseTable_filter').find('label').css({"color": "black"});
	jQuery('.dataTable').wrap('<div class="dataTables_scroll" />');
	
	 var table = $('#reuseTable').DataTable();
	$('#reuseTable tbody').on( 'click', 'tr td:nth-child(4)', function () {
		
		reuseprojectName = table.row($(this)).data().projectName;
		reuseSummary=table.row($(this)).data().summary;
		reuseContactPersonName=table.row($(this)).data().contactPerson;
		reuseAutomationName=table.row($(this)).data().reuseComponentName;
		reusedownloadCountval=table.row($(this)).data().downloadCounter;
		reuseContributorName=table.row($(this)).data().contributorName;
		//showRowData();
	} );
	
	$('#reuseTable tbody').on( 'click', 'tr td:nth-child(10)', function () {
		reuseExcelDownloadId=table.row($(this)).data().reuseId;
		reusedownloadCount=table.row($(this)).data().downloadCounter;
		updateDownloadCount(reuseExcelDownloadId);
		var cell = table.cell(this);
		var cell2 = table.cell(cell.index().row,cell.index().column+1);
		cell2.data( cell2.data() + 1 ).draw();

	
	} );
	
} 
function showRowData() {
 //$("#sucessmsg").html('');
 //$("#contributorFeedBackId").show();
		
		   		 var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/reuseRewardAlreadyExist";
				$.ajax({
						url:predixurl,
                         type: "POST", //send it through post method
						contentType: "application/json",
						data :JSON.stringify({
						  automationName :reuseAutomationName,
						  projectName : reuseprojectName,
						  contributorName:reuseContributorName,
						  userId:userId,
					     }),
						
                         success: function(responseData) {
						
						
                	         if((responseData.status == 201)&&(responseData.message == "Exists")){
                	 
								//$("#contributorFeedBackId").hide();
								  $("#commentId").val(responseData.object.comment);
								//  $("#commentId").prop("disabled", true);
								  $("#ratingId").rating("update", responseData.object.starRating);
								   $("#contributorFeedBackId").prop('value', 'update');
								 }else{
								 $("#commentId").val('');
								 $("#ratingId").rating();
								 $("#ratingId").rating("update", 0);
								// $("#commentId").prop("disabled", false);
								 $("#contributorFeedBackId").show();
								 $("#contributorFeedBackId").prop('value', 'save');
								
                	         }
							$('#automationModal').modal("show");
     			},
                 error: function ( xhr, status, error) {
				 console.log("Error while Login");
				 
		        }
		});
		 if(automationIdvar!=''){
			   totalCount(automationIdvar);
		   }
		  
           var businessName = $(this).children('td').eq(1).text();
		  
		   var summary = summaryArray[slnovar];
		  // var fileName=$(this).children('td').eq(11).text();
		  
		   
		   $('#projectName').html(projectNamevar);
		   $('#automationName').html(automationNameVar);
		   $('#summaryId').html(summary);
		   $('#contributorId').html(contributorNamevar);
		   if(fileNameVar != '' ){
		   }else{
		      $('#pptFileId').html('');
		   }
		   $('#contactPersonID').html(contactPersonNamevar);
		   
		   if(automationStatus=='Completed'){
			    $('#autostatus').html('<span style="color:#1dce1d;font-Weight:bold">'+automationStatus+'</span>');
		   }else{
			    $('#autostatus').html('<span style="color:blue;font-Weight:bold">'+automationStatus+'</span>');
		   }
		  
                        
        //});
    //});
	
}
function updateDownloadCount(reuseExcelDownloadId){
			 if(reuseExcelDownloadId!=''){
		        var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/updateDownloadCountForReuse/"+reuseExcelDownloadId;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
						   
                        console.log(responseData.status);
                        if(responseData.status == 200 && responseData.message=="Success"){
						   // totalCount(automationId);
                        }
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while updating download count in Automation_Tracker table.");
	                }
		       });
		     }
			 
        // });
    //});
} // End of updateDownloadCount()
function getUserIdFromName(decryptedUserName1){
	
var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getUserIdFromUserName/"+decryptedUserName1;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
						
                        console.log(responseData.status);
                        if(responseData.status == 200 && responseData.message=="Success"){
						  userId=responseData.object.userId;
						
                        }else{
							
							
						}
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while updating download count in Automation_Tracker table.");
	                }
		       });
}