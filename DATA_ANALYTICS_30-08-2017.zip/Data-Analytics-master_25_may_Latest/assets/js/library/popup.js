// timeout.js
 
/*var idleTime = 0;

$(document).ready(function () {
    //var idleInterval = setInterval(timerIncrement, 1000*60*20);
	var idleInterval = setInterval(timerIncrement, 1080000);


    $(this).mousemove(function (e) {
        idleTime = 0;
    });
    $(this).keypress(function (e) { 
        idleTime = 0;
    });
    $(".sleepy-close, .sleepy-overlay, .sleepy-wake-up, .idleyes-btn").click(function () {
        $(".sleepy-overlay").hide();
        idleTime = 0;
    });
    $('.sleepy-modal').click(function (event) {
        event.stopPropagation();
    });


function timerIncrement() {

    idleTime = idleTime + 1;
    if (idleTime > 1) {
        $('.sleepy-overlay').fadeIn('slow');
        idleTime = 0;
		var idleYes = setInterval(idlelogout, 20000);
		//clearinterval when popup show 
		$(".idleyes-btn").click(function () {
			$(".sleepy-overlay").hide();
			idleTime = 0;
			clearInterval(idleYes);
		});
 		
    }
}

function idlelogout() {		
		//alert("timeout111");
		//location.href = 'index.html';
		//logout();
		document.cookie = encodeURIComponent("sc_sso") + "=deleted; expires=" + new Date(0).toUTCString();
		document.cookie = encodeURIComponent("sc_token") + "=deleted; expires=" + new Date(0).toUTCString();
		
		var fullUrl = window.location.href;
		var extractUrl = fullUrl.split('//');
		var extractUrl1=extractUrl[1];
		var extractUrl2 = extractUrl1.split('/')
		var finalUrl = extractUrl2[0]+"/logout"; 
		var logoutUrl = finalUrl; 
		window.location.replace("https://"+finalUrl);
		
		}
		
});

*/