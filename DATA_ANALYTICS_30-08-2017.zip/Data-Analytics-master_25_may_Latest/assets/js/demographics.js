 $(document).ready(function () {
	 $('#yearId').html(new Date().getFullYear());
		var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
		
		
		 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
		
	$("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	  
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	$("#automationId").click(function(){
        window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	});
	 
	 
	 $("#contributorIdList").click(function(){
	window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
				
		 
	 });
	 
	 $("#workId").click(function(){
		window.location="poc.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  })
		
 });
 var starRatingLength;
 function showCoeInfo(data){
	var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getTeamMemberDetails";
		     $.ajax({
		          url:predixurl+"/"+data,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
					  
					$("#dispalyName").html(responseData.displayName);
					$("#firstName").html(responseData.firstName);	
					$("#lastName").html(responseData.lastName);	
					$("#employeeId").html(responseData.empId);	
					$("#roleId").html(responseData.role);	
					$("#jobtitle").html(responseData.jobTitle);
					$("#emailId").html(responseData.email);
					$("#workphone").html(responseData.workPhone);
					$("#businessunit").html(responseData.businessUnit);
					$("#teamImageId").html('<img src="assets/img/team/'+responseData.empId+'.jpg"/>');
					starRatingLength=responseData.starRating;
					 var rewardStr='';
					var rewardCount=0;
					for(var i=0;i<starRatingLength;i++){
						if(responseData.rewardName == "Pat On Back FY 16-17 Q4"){
								    rewardStr = rewardStr + '<tr><td style="width: 198px"><img src="assets/img/badges_bravo.jpg" style="width:73px;height:73px;"/><br>Pat On Back FY 16-17 Q4</td><td></td><td></td></tr>' + "  ";
									rewardCount = rewardCount + 1;
								}
					}
					
					$("#rewardImage").html(rewardStr);
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });
	 
	 
	 
 }
 
 