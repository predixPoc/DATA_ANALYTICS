 
 var dataRatingVal=0;
 var x;
 $(document).ready(function () {
	$('#yearId').html(new Date().getFullYear());
	 
	 $("#ratingId").rating();
	 $("#awardDetailsId").hide();
	
	 var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
	 
	 
	var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getAllContributorList";
	
		     $.ajax({
		          url:predixurl,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
					for (var i = 0; i < responseData.length; i++) {
						$('#contributorNameIdList1').append($('<option>', { 
						value: responseData[i].trim(),
						text : responseData[i].trim()
				}));
				}
					
					
					
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });
			 
			 
  $("#contributorNameIdList1").change(function () {


     var projectNameList='';
                var contributorName=$(this).val();
                var businessName='';
                var totalStarRating=0;
                var averageStarRating=0;
                var contributorSvcUrl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getRewardDetailsForContriutor";
                
                 $.ajax({
                  url:contributorSvcUrl+"/"+contributorName,
                  type: "GET", 
                  success: function(responseData) {
                  var totalRecords=responseData.length;
                  var rating;
                                                                                                
                  for (var i = 0; i < totalRecords; i++) {                                                                                                         
                      businessName=responseData[i].businessName;
                      rating=responseData[i].starRating;
                      if(rating != 'Not Rated'){
																																					totalStarRating=totalStarRating+parseFloat(rating);
					}
					projectNameList=projectNameList+responseData[i].projectName+"<br><br>";                                               
             }
                                                                                                
             averageStarRating=totalStarRating/totalRecords;
                                                                                                
             $("#businessName").html(businessName);
             $("#projectnameId").html(projectNameList);
                                                                                                
             $("#contributorNameId").html(contributorName);
             $("#ratingId").rating("update", averageStarRating);                                                                                        
             $("#awardDetailsId").show();
                                     },
             error: function ( xhr, status, error) {
               console.log("Error while fetching Contribution List data.");
                             }
          });

   });

   
   
   
   
    $("#automationId").click(function(){
          window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	  $("#workId").click(function(){
		window.location="poc.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	  $("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	  $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
	  });
	  
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  });

 });