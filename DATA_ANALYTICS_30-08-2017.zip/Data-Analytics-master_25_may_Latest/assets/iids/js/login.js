function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
  return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var fedHost = getParameterByName('fedHost');
var resumePath = getParameterByName('resumePath');
var targetSAML;
var action;
if(document.location.hostname.indexOf("dev") === 0 || document.location.hostname.indexOf("qa") === 0) {
    //staging
    targetSAML = 'https://ssostagingck.registrar.ge.com/PfIdpSmAuth/PFCustFormRedir.jsp?fedHost=' + fedHost + '&resumePath=' + resumePath;
    action = "https://ssologin.qagen2.corporate.ge.com/SSOLogin/verify.fcc";
} else {
    //production
    targetSAML = 'https://ssocentralck.registrar.ge.com/PfIdpIntegSmAuth/pfstdworkerredirect.jsp?fedHost=' + fedHost + '&resumePath=' + resumePath;
    action = "https://ssousflogin.corporate.ge.com/SSOLogin/verify.fcc";
}

function setCookie(name, value, expires, path, domain, secure) {
  var curCookie = name + "=" + escape(value) +
    ((expires) ? "; expires=" + expires.toGMTString() : "") +
    ((path) ? "; path=" + path : "") +
    ((domain) ? "; domain=" + domain : "") +
    ((secure) ? "; secure" : "");
  document.cookie = curCookie;
}

function window_onload() {
  document.signon.username.focus();
}